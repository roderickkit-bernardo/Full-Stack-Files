/* 
  Developer: 
  Purpose: 
*/

/* 
Implement any loop type to display the 
following output on the browser console

Step 1
Step 2
Step 3
Step 4
Step 5
*/

/* 
Implement any loop type to display the 
following output on the browser console

Step 5
Step 4
Step 3
Step 2
Step 1
*/

/* 
Implement any loop type to display the even numbers to 10
and display on the browser console

Step 2
Step 4
Step 6
Step 8
Step 10 
*/

/* 
Implement any loop type to display the odd numbers to 9 
and display on the browser console

Step 1
Step 3
Step 5
Step 7
Step 9
*/
