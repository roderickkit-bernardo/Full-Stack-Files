/* 
  Developer: 
  Purpose: 
*/

// Declare a variable named orders and set it to 100

// Display the value of the variable on the browser console

// Add 5 to orders

// Display the value of the variable on the browser console

// Subtract 55 to orders

// Display the value of the variable on the browser console

// Multiply 2 to orders

// Display the value of the variable on the browser console

// Divide by 4 to orders

// Display the value of the variable on the browser console

// Modulus by 7 to orders

// Raise orders to the 4th power

// Display the value of the variable on the browser console

// Increment orders

// Display the value of the variable on the browser console

// Decrement orders

// Display the value of the variable on the browser console

// Declare a variable named street1 and set it to "Yonge"

// Declare a variable named street2 and set it to "Dundas"

// Declare a variable named location
// Use string1 and string2 to produce this output:
// Yonge and Dundas

// Display the value of the variable on the browser console

// Declare a variable named validateInput
// Set it to parseFloat(string1);
// Display the value of the variable on the browser console

// Set it to isNaN(string1);
// Display the value of the variable on the browser console

// Set it to parseInt(string2);
// Display the value of the variable on the browser console

// Set it to isNaN(string2);
// Display the value of the variable on the browser console

// Set it to parseFloat("12345.99");
// Display the value of the variable on the browser console

// Set it to parseInt("123456");
// Display the value of the variable on the browser console
