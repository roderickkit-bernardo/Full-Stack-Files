// Developer: Roderick Bernardo
// Purpose: Front-end to the library app

import { useContext } from "react";
//  Use data context to share data app-wide
import { DataContext } from "./DataContext";
import { logout } from "./Logout";

function Loans(props) {
  //  Use data context to share data app-wide
  const [refreshData, setRefreshData] = useContext(DataContext);

  // Return a book
  const returnHandler = (event) => {
    const url = `${import.meta.env.VITE_API_BASE_URL}${
      import.meta.env.VITE_API_BOOK
    }${import.meta.env.VITE_API_BOOK_RETURN}/${event.target.id}`;

    const options = {
      method: "PUT",
      headers: {
        "x-api-key": sessionStorage.getItem("token"),
      },
    };

    const fetchData = async () => {
      try {
        const response = await fetch(url, options);
        const responseJson = await response.json();

        if (response.status == 200) {
          if (
            responseJson.message.startsWith("Successfully returned the book")
          ) {
            setRefreshData(new Date());
          }

          alert(responseJson.message);
        } else {
          logout(
            "Token is either invalid or expired. You will be directed to the login page."
          );
        }
      } catch (error) {
        console.log(error);
        alert(`Network error please try again.`);
      } finally {
      }
    };

    fetchData();
  };

  return (
    <div
      id="collapseLoan"
      className="accordion-collapse collapse"
      data-bs-parent="#accordionExample"
    >
      <div className="accordion-body">
        <div className="d-flex justify-content-around gap-4 flex-wrap">
          {props.loan.map((item, index) => (
            <div className="card" key={index}>
              <div className="card-header">
                <h5 className="card-title">Loan Id: {item.LOAN_ID}</h5>
              </div>
              <div className="card-body">
                <h5 className="card-title">ISBN: {item.BOOK_ISBN}</h5>
                <h5 className="card-title">
                  Borrow Date: {item.LOAN_BORROW_DATE}
                </h5>
                <button
                  className="btn btn-primary"
                  id={item.LOAN_ID}
                  onClick={returnHandler}
                >
                  Return
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Loans;
