Build Instructions:

1. Run the sql script (Library-App.sql) against your MySQL Database instance.

2. To run the backend execute the following commands:
npm install
npm run start

3. To run the frontend execute the following commands:
npm install
npm run dev
