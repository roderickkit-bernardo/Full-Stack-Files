// Developer: Roderick Bernardo
// Purpose: Express API router app

import { Router, Request, Response } from "express";
import { MySqlDB } from "../lib/MySqlDB";

const mySqlDB: MySqlDB = new MySqlDB();

export const loanV1 = Router();

// Get all loaned items
loanV1.get("/", async (req: Request, res: Response) => {
  let queryResult;
  const connectResponse = await mySqlDB.connect();
  const query = "SELECT * FROM LOAN";

  if (connectResponse.isConnected) {
    queryResult = await mySqlDB.query(query);
    const disConnectResponse = await mySqlDB.disConnect();
  }

  res.json(queryResult[0]);
});

// Get loaned items based on username
loanV1.get("/:userName", async (req: Request, res: Response) => {
  const userName: string = req.params.userName;
  let queryResult;
  let options: any;
  const connectResponse = await mySqlDB.connect();
  const query =
    "SELECT * FROM LOAN WHERE USER_NAME = ? AND LOAN_RETURN_DATE IS NULL";

  if (connectResponse.isConnected) {
    options = [userName];
    queryResult = await mySqlDB.query(query, options);
    const disConnectResponse = await mySqlDB.disConnect();
  }

  res.json(queryResult[0]);
});
