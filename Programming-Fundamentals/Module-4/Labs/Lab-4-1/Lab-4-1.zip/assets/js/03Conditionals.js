/* 
  Developer: 
  Purpose: 
*/

// Implement the if / else logic based on the following conditions
// Variable is monthNumber
// if monthNumber is equal to 12 or 1 or 2
// Display on the console "WINTER"
// if monthNumber is equal to 3 or 4 or 5
// Display on the console "SPRING"
// if monthNumber is equal to 6 or 7 or 8
// Display on the console "SUMMER"
// if monthNumber is equal to 9 or 10 or 11
// Display on the console "FALL"

// Implement the logic above to use switch statement
