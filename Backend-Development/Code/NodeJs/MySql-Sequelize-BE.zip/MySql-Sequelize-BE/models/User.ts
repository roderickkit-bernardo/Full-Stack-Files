// Developer: Roderick Bernardo
// Purpose: MySql sequelize backend sample

import { DataTypes, Model, Optional } from "sequelize";
import sequelize from "../config/Database";

// Define the attributes for the User model
interface UserAttributes {
  ID: number;
  USER_NAME: string;
  EMAIL: string;
  CREATED_AT: Date;
}

// Define the creation attributes for the User model
// If the field is optional then define it here
interface UserCreationAttributes
  extends Optional<UserAttributes, "ID" | "CREATED_AT"> {}

// Define the User model class
class User
  extends Model<UserAttributes, UserCreationAttributes>
  implements UserAttributes
{
  public ID!: number; // ! means not null
  public USER_NAME!: string; // ! means not null
  public EMAIL!: string; // ! means not null
  public readonly CREATED_AT!: Date; // readonly means property as immutable
}

// Initialize the User model
User.init(
  {
    ID: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    USER_NAME: {
      type: new DataTypes.STRING(50),
      allowNull: false,
      unique: true,
    },
    EMAIL: {
      type: new DataTypes.STRING(50),
      allowNull: false,
      unique: true,
    },
    CREATED_AT: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    sequelize,
    // Specifying the table means we are using an existing table
    // If you don't specify the table name Sequelize will use the pluralized version of the model
    // For instance the model is USER then Sequelize will look for USERS on your DB
    tableName: "USERS",
    timestamps: false,
  }
);

export default User;
