// Developer: Roderick Bernardo
// Purpose: Front-end to the library app

// The following components are used by the Libary component
import Nav from "./Nav";
import Books from "./Books";
import Loans from "./Loans";
import { logout } from "./Logout";

import { useState, useEffect, useContext } from "react";

//  Use data context to share data app-wide
import { DataContext } from "./DataContext";

function Library() {
  //  Use data context to share data app-wide
  const [refreshData, setRefreshData] = useContext(DataContext);
  const [book, setBook] = useState([]);
  const [loan, setLoan] = useState([]);

  // Download the list of books that is not yet borrowed by the current user
  useEffect(() => {
    const fetchData = async () => {
      const options = {
        headers: {
          "x-api-key": sessionStorage.getItem("token"),
        },
      };

      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}${
          import.meta.env.VITE_API_BOOK
        }/${sessionStorage.getItem("userName")}`,
        options
      );
      const responseJson = await response.json();

      if (response.status == 200) {
        setBook(responseJson);
      } else {
        logout("");
      }
    };

    fetchData();
  }, [refreshData]);

  // Download the list of books that are borrowed
  useEffect(() => {
    const fetchData = async () => {
      const options = {
        headers: {
          "x-api-key": sessionStorage.getItem("token"),
        },
      };

      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}${
          import.meta.env.VITE_API_LOAN
        }/${sessionStorage.getItem("userName")}`,
        options
      );

      const responseJson = await response.json();
      if (response.status == 200) {
        setLoan(responseJson);
      } else {
        logout(
          "Token is either invalid or expired. You will be directed to the login page."
        );
      }
    };

    fetchData();
  }, [refreshData]);

  return (
    <div className="container">
      <Nav navData="Library App"></Nav>

      <div className="accordion" id="libraryAppAccordion">
        <div className="accordion-item">
          <h2 className="accordion-header">
            <button
              className="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#collapseBooks"
              aria-expanded="false"
              aria-controls="collapseBooks"
            >
              Available Books: ({book.length})
            </button>
          </h2>
          {/* Load the Books component */}
          <Books book={book}></Books>
        </div>
        <div className="accordion-item">
          <h2 className="accordion-header">
            <button
              className="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#collapseLoan"
              aria-expanded="false"
              aria-controls="collapseLoan"
            >
              Items Borrowed: ({loan.length})
            </button>
          </h2>
          {/* Load the Loans component */}
          <Loans loan={loan}></Loans>
        </div>
      </div>
    </div>
  );
}

export default Library;
