// Developer: Roderick Bernardo
// Purpose: React router demo
function NotFound() {
  return (
    <section class="hero">
      <div class="hero-body">
        <p class="title has-text-centered">Page Not Found</p>
      </div>
    </section>
  );
}

export default NotFound;
