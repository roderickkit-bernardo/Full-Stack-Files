// Developer: Roderick Bernardo
// Purpose: Express API router app

import { Router, Request, Response } from "express";
import { MySqlDB } from "../lib/MySqlDB";

const mySqlDB: MySqlDB = new MySqlDB();

export const bookV1 = Router();

// Get list of all books
bookV1.get("/", async (req: Request, res: Response) => {
  let queryResult;
  const connectResponse = await mySqlDB.connect();
  const query = "SELECT * FROM BOOK";

  if (connectResponse.isConnected) {
    queryResult = await mySqlDB.query(query);
  }

  res.json(queryResult[0]);
});

//  Get list of books that has not been borrowed by the user
bookV1.get("/:userName", async (req: Request, res: Response) => {
  const userName: string = req.params.userName;
  let queryResult;
  let options: any;
  const connectResponse = await mySqlDB.connect();
  const query = `SELECT B.BOOK_ISBN, B.BOOK_TITLE, B.BOOK_AVAILABLE_COPIES FROM BOOK B WHERE B.BOOK_ISBN NOT IN (SELECT L.BOOK_ISBN FROM LOAN L WHERE L.LOAN_RETURN_DATE IS NULL AND L.USER_NAME = ?)`;

  if (connectResponse.isConnected) {
    options = [userName];
    queryResult = await mySqlDB.query(query, options);
  }

  res.json(queryResult[0]);
});

// Borrow a book
bookV1.post(
  "/:action/:userName/:bookIsbn",
  async (req: Request, res: Response) => {
    // Parameters needed
    const action: string = req.params.action;
    const userName: string = req.params.userName;
    const bookIsbn: string = req.params.bookIsbn;
    let loanId: number = 0;
    let queryResult;
    let options: any;
    let message: string = "";

    const connectResponse = await mySqlDB.connect();

    if (action == "borrow") {
      if (connectResponse.isConnected) {
        // Borrow book step 1
        options = [userName, bookIsbn];
        queryResult = await mySqlDB.query(
          `INSERT INTO LOAN (USER_NAME, BOOK_ISBN, LOAN_BORROW_DATE, LOAN_RETURN_DATE) VALUES (?, ?, CURRENT_TIMESTAMP, NULL)`,
          options
        );

        loanId = queryResult[0].insertId;

        if (loanId > 0) {
          // Borrow book step 2
          options = [bookIsbn];
          queryResult = await mySqlDB.query(
            `UPDATE BOOK SET BOOK_AVAILABLE_COPIES = BOOK_AVAILABLE_COPIES - 1 WHERE BOOK_ISBN = ?`,
            options
          );

          if (queryResult[0].changedRows == 1) {
            message = `Successfully borrowed the book ${bookIsbn}.`;
          } else {
            message = "Failed to update the book table.";
          }
        } else {
          message = "Failed to insert the loan table.";
        }
      }
    } else {
      message = "Invalid action.";
    }

    if (connectResponse.isConnected) {
      const disConnectResponse = await mySqlDB.disConnect();
    }

    res.json({
      userName: userName,
      bookIsbn: bookIsbn,
      loanId: loanId,
      message: message,
    });
  }
);

// Return a book
bookV1.put("/:action/:loanId", async (req: Request, res: Response) => {
  // Parameters needed
  const action: string = req.params.action;
  const loanId: string = req.params.loanId;
  let userName: string = "";
  let bookIsbn: string = "";
  let queryResult;
  let options: any;
  let message: string = "";

  const connectResponse = await mySqlDB.connect();

  if (action == "return") {
    if (connectResponse.isConnected) {
      // Return book step 1
      options = [loanId];
      queryResult = await mySqlDB.query(
        `UPDATE LOAN SET LOAN_RETURN_DATE = CURRENT_TIMESTAMP WHERE LOAN_ID = ?`,
        options
      );

      if (queryResult[0].changedRows == 1) {
        // Return book step 2
        options = [loanId];
        queryResult = await mySqlDB.query(
          "SELECT USER_NAME, BOOK_ISBN FROM LOAN WHERE LOAN_ID = ?",
          options
        );

        userName = queryResult[0][0].USER_NAME;
        bookIsbn = queryResult[0][0].BOOK_ISBN;
        options = [bookIsbn];
        queryResult = await mySqlDB.query(
          `UPDATE BOOK SET BOOK_AVAILABLE_COPIES = BOOK_AVAILABLE_COPIES + 1 WHERE BOOK_ISBN = ?`,
          options
        );
        message = `Successfully returned the book ${bookIsbn}.`;
      } else {
        message = "Failed to update the book table.";
      }
    } else {
      message = "Failed to update the loan table.";
    }
  } else {
    message = "Invalid action.";
  }

  if (connectResponse.isConnected) {
    const disConnectResponse = await mySqlDB.disConnect();
  }

  res.json({
    userName: userName,
    bookIsbn: bookIsbn,
    loanId: loanId,
    message: message,
  });
});
