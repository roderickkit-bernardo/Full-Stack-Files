// Developer: Roderick Bernardo
// Purpose: Express API router app

import { Router, Request, Response } from "express";
import { MySqlDB } from "../lib/MySqlDB";
import { verifyPassword } from "../lib/PasswordHasherES6";

const mySqlDB: MySqlDB = new MySqlDB();

export const userV1 = Router();

// Get all users
userV1.get("/", async (req: Request, res: Response) => {
  let queryResult;
  const connectResponse = await mySqlDB.connect();
  const query = "SELECT USER_NAME, USER_FNAME, USER_LNAME FROM USER";

  if (connectResponse.isConnected) {
    queryResult = await mySqlDB.query(query);
    const disConnectResponse = await mySqlDB.disConnect();
  }

  res.json(queryResult[0]);
});

// Verify the plain password with the hashed password
userV1.post("/verifyPassword", async (req: Request, res: Response) => {
  const userName = req.body.userName;
  const password = req.body.password;
  let queryResult;
  let options: any;
  let verifyPasswordResponse: any = { status: "failure", isMatch: false };

  const connectResponse = await mySqlDB.connect();
  options = [userName];
  const query = "SELECT USER_PASSWORD FROM USER WHERE USER_NAME = ?";

  if (connectResponse.isConnected) {
    queryResult = await mySqlDB.query(query, options);
    verifyPasswordResponse = await verifyPassword(
      password,
      queryResult[0][0].USER_PASSWORD
    );

    const disConnectResponse = await mySqlDB.disConnect();
  }

  res.json(verifyPasswordResponse);
});
