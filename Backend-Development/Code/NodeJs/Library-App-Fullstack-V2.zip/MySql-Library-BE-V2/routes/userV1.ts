// Developer: Roderick Bernardo
// Purpose: Express API router app

import jwt from "jsonwebtoken";
import { Router, Request, Response } from "express";
import { MySqlDB } from "../lib/MySqlDB";
import { hashPassword, verifyPassword } from "../lib/PasswordHasherES6";
import { authApiToken } from "../lib/AuthApiToken";
const mySqlDB: MySqlDB = new MySqlDB();

export const userV1 = Router();

// Get all users
userV1.get("/", authApiToken, async (req: Request, res: Response) => {
  let queryResult;
  const connectResponse = await mySqlDB.connect();
  const query = "SELECT USER_NAME, USER_FNAME, USER_LNAME FROM USER";

  if (connectResponse.isConnected) {
    queryResult = await mySqlDB.query(query);
    const disConnectResponse = await mySqlDB.disConnect();
  }

  res.json(queryResult[0]);
});

// Create a user
userV1.post("/", authApiToken, async (req: Request, res: Response) => {
  const { USER_NAME, USER_FNAME, USER_LNAME, USER_PASSWORD } = req.body;
  const HASHED_PASSWORD = await hashPassword(USER_PASSWORD);
  let queryResult;
  let options: any;
  let postReponse: any = { status: "", message: "" };

  const connectResponse = await mySqlDB.connect();
  options = [USER_NAME, USER_FNAME, USER_LNAME, HASHED_PASSWORD.hashedPassword];
  const query =
    "INSERT INTO USER(USER_NAME, USER_FNAME, USER_LNAME, USER_PASSWORD) VALUES(?, ?, ?, ?)";

  if (connectResponse.isConnected) {
    queryResult = await mySqlDB.query(query, options);
    console.log(queryResult[0]);
    if (queryResult[0].affectedRows == 1) {
      postReponse.status = "success";
      postReponse.message = `Successfully created username: ${USER_NAME}.`;
    } else {
      postReponse.status = "failure";
      postReponse.message = `Failed to create username: ${USER_NAME}.`;
    }

    const disConnectResponse = await mySqlDB.disConnect();
  } else {
    postReponse.status = "failure";
    postReponse.message = connectResponse.message;
  }

  res.json(postReponse);
});

// Verify the plain password with the hashed password
userV1.post("/verifyPassword", async (req: Request, res: Response) => {
  const userName = req.body.userName;
  const password = req.body.password;
  let queryResult;
  let options: any;
  let verifyPasswordResponse: any = {
    status: "failure",
    isMatch: false,
    token: "",
  };

  const connectResponse = await mySqlDB.connect();
  options = [userName];
  const query = "SELECT USER_PASSWORD FROM USER WHERE USER_NAME = ?";

  if (connectResponse.isConnected) {
    queryResult = await mySqlDB.query(query, options);
    if (queryResult[0].length == 1) {
      verifyPasswordResponse = await verifyPassword(
        password,
        queryResult[0][0].USER_PASSWORD
      );
      verifyPasswordResponse.token = jwt.sign(
        { userName: userName },
        String(process.env.SECRET_TOKEN_KEY),
        {
          expiresIn: "1h", // One hour expiration
        }
      );
    }

    const disConnectResponse = await mySqlDB.disConnect();
  }

  res.json(verifyPasswordResponse);
});
