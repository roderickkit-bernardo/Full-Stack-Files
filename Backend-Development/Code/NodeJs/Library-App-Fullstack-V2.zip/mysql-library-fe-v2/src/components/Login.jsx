// Developer: Roderick Bernardo
// Purpose: Front-end to the library app

import { useState, useEffect } from "react";
import Library from "./Library";

function Login() {
  // Keep track of the login state
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return sessionStorage.getItem("isLoggedIn") || false;
  });

  useEffect(() => {
    if (isLoggedIn) {
      sessionStorage.setItem("isLoggedIn", isLoggedIn);

      if (formValues.userName) {
        // When the user is logged in capture the username
        sessionStorage.setItem("userName", formValues.userName);
      }
    }
  }, [isLoggedIn]);

  // Initializa the username and password form values
  const [formValues, setFormValues] = useState({
    userName: "",
    password: "",
  });

  // Keep track of the changes to the username and password
  const changeHandler = (event) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  // Handler for the form
  const submitHandler = (event) => {
    // Do not submit the form automatically
    event.preventDefault();

    // Simple field validation
    if (formValues.userName.length > 0 && formValues.password.length > 0) {
      // Build the post request
      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userName: formValues.userName,
          password: formValues.password,
        }),
      };

      // Build the post url
      const url = `${import.meta.env.VITE_API_BASE_URL}${
        import.meta.env.VITE_API_VERIFY_USER_NAME_AND_PASSWORD
      }`;

      //  Define the fetch api call
      const fetchData = async () => {
        try {
          const response = await fetch(url, options);
          const responseJson = await response.json();

          if (responseJson.status == "success" && responseJson.isMatch) {
            setIsLoggedIn(true);
            // Save the token, this is will be used in subsequent requests
            sessionStorage.setItem("token", responseJson.token);
          } else {
            alert(`Invalid user name or password.`);
          }
        } catch (error) {
          console.log(error);
          alert(`Network error please try again.`);
        } finally {
        }
      };

      fetchData();
    } else {
      alert(`Blank values are not allowed.`);
    }
  };

  // Show the login form when the user is not logged in
  if (!isLoggedIn) {
    return (
      <div className="container mt-5">
        <h2 className="mb-4">Library App</h2>
        <form onSubmit={submitHandler}>
          <div className="mb-3">
            <label htmlFor="userName" className="form-label">
              User Name
            </label>
            <input
              type="text"
              name="userName"
              id="userName"
              value={formValues.userName}
              onChange={changeHandler}
              className="form-control"
              placeholder="Enter your user name"
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password" className="form-label">
              Password
            </label>
            <input
              type="password"
              name="password"
              id="password"
              value={formValues.password}
              onChange={changeHandler}
              className="form-control"
              placeholder="Enter your password"
            />
          </div>

          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    );
  }
  //  If the user is logged in show the library app
  else {
    return <Library></Library>;
  }
}

export default Login;
