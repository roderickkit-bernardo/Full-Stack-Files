// Developer: Roderick Bernardo
// Purpose: MySql sequelize backend sample

import { Router, Request, Response } from "express";
import User from "../models/User";

export const userV1 = Router();

// Get one user
userV1.get("/:id", async (req: Request, res: Response) => {
  const options = { where: { ID: req.params.id } };
  let user: any = await User.findOne(options);

  if (!user) {
    return res.json({});
  }

  return res.json(user);
});

// Get all users
userV1.get("/", async (req: Request, res: Response) => {
  const users = await User.findAll();

  return res.json(users);
});

// Create a user
userV1.post("/", async (req: Request, res: Response) => {
  const newUser = await User.create(req.body);

  if (newUser?.dataValues?.ID) {
    return res.json(newUser.toJSON());
  } else {
    return res.json({});
  }
});

// Update a user
userV1.put("/:id", async (req: Request, res: Response) => {
  const updatedUser = await User.update(req.body, {
    where: { ID: req.params.id },
  });

  const updateStatus = { status: `Failed to update ID: ${req.params.id}.` };
  if (updatedUser[0] == 1) {
    updateStatus.status = `ID: ${req.params.id} updated sucessfully.`;
  }

  return res.json(updateStatus);
});

// Delete all user
userV1.delete("/", async (req: Request, res: Response) => {
  const destroyedUsers = await User.destroy({ where: {} });
  const deleteStatus = { status: `Deleted ${destroyedUsers} users.` };
  return res.json(deleteStatus);
});

// Delete one user
userV1.delete("/:id", async (req: Request, res: Response) => {
  const destroyedUser = await User.destroy({
    where: { ID: req.params.id },
  });

  const deleteStatus = { status: `Failed to delete ID: ${req.params.id}.` };
  if (destroyedUser == 1) {
    deleteStatus.status = `ID: ${req.params.id} deleted sucessfully.`;
  }

  return res.json(deleteStatus);
});
