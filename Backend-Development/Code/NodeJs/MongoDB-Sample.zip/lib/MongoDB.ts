// Developer: Roderick Bernardo
// Purpose: MongoDB client sample

import { MongoClient, Collection } from "mongodb";
import { DBConnectionFields } from "../models/DBConnectionFields";

export class MongoDB {
  dbConnectionFields: DBConnectionFields;
  client: MongoClient;

  constructor() {
    this.dbConnectionFields = {
      userName: String(process.env.MONGO_USER),
      password: String(process.env.MONGO_PASSWORD),
      url: `${String(process.env.MONGO_HOST)}:${String(
        process.env.MONGO_PORT
      )}`,
      urlScheme: String(process.env.MONGO_URL_SCHEME),
      db: String(process.env.MONGO_DOCUMENT_NAME),
    };

    this.client = new MongoClient(
      `${this.dbConnectionFields.urlScheme}${this.dbConnectionFields.userName}:${this.dbConnectionFields.password}@${this.dbConnectionFields.url}`
    );
  }

  async connect() {
    const connectResponse = { isConnected: false, message: "" };
    try {
      await this.client.connect();
      connectResponse.isConnected = true;
      connectResponse.message = `Connected to: ${this.dbConnectionFields.url}.`;
    } catch (error: any) {
      connectResponse.message = `Could not connect to: ${this.dbConnectionFields.url}.`;
    } finally {
      return connectResponse;
    }
  }

  async find(collectionName: string, options: any) {
    const db = this.client.db(this.dbConnectionFields.db);
    const collection: Collection = db.collection(collectionName);
    let findResponse: any = null;
    findResponse = collection.find(options);
    const findResponseArray = await findResponse.toArray();
    return findResponseArray;
  }

  async insert(collectionName: string, options: any) {
    const db = this.client.db(this.dbConnectionFields.db);
    const collection: Collection = db.collection(collectionName);
    let insertOneResponse: any = null;
    insertOneResponse = await collection.insertOne(options);
    return insertOneResponse;
  }

  async update(collectionName: string, key: any, value: any) {
    const db = this.client.db(this.dbConnectionFields.db);
    const collection: Collection = db.collection(collectionName);
    let updateOneResponse: any = null;
    updateOneResponse = await collection.updateMany(key, value);
    return updateOneResponse;
  }

  async delete(collectionName: string, options: any) {
    const db = this.client.db(this.dbConnectionFields.db);
    const collection: Collection = db.collection(collectionName);
    let deleteManyResponse: any = null;
    deleteManyResponse = await collection.deleteMany(options);
    return deleteManyResponse;
  }

  async disConnect() {
    const disConnectResponse = {
      isDisconnected: false,
      message: "",
    };

    try {
      await this.client.close();
      disConnectResponse.isDisconnected = true;
      disConnectResponse.message = `Disconnected to: ${this.dbConnectionFields.url}.`;
    } catch (error: any) {
      disConnectResponse.message = `Could not disconnect to: ${this.dbConnectionFields.url}.`;
    } finally {
      return disConnectResponse;
    }
  }
}
