// Developer: Roderick Bernardo
// Purpose: Front-end to the library app

import { createContext } from "react";
export const DataContext = createContext();
