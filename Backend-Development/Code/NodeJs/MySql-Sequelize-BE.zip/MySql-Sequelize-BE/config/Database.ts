// Developer: Roderick Bernardo
// Purpose: MySql sequelize backend sample

import { Sequelize } from "sequelize";

const sequelize = new Sequelize(
  String(process.env.SQL_DB_NAME),
  String(process.env.SQL_USER),
  String(process.env.SQL_PASSWORD),
  {
    host: String(process.env.SQL_HOST),
    dialect: "mysql",
  }
);

export default sequelize;
