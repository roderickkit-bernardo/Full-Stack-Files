// Developer: Roderick Bernardo
// Purpose: MongoDB client sample

import * as dotenv from "dotenv";
dotenv.config();
import { MongoDB } from "./lib/MongoDB";

async function main() {
  console.time("Benchmark");
  const mongoDB: MongoDB = new MongoDB();
  const connectResponse = await mongoDB.connect();
  console.log(connectResponse);
  if (connectResponse.isConnected) {
    let users: any = null;

    console.log("===========================");
    console.log("= Select all documents... =");
    console.log("===========================");

    users = await mongoDB.find("users", {});
    console.log(users);

    console.log("==========================");
    console.log("= Select one document... =");
    console.log("==========================");

    users = await mongoDB.find("users", { userName: "elon.musk" });
    console.log(users);

    console.log("==========================");
    console.log("= Insert one document... =");
    console.log("==========================");

    const insertResponse = await mongoDB.insert("users", {
      userName: "steve.jobs",
      email: "steve.jobs@apple.com",
      createdAt: new Date(),
    });
    console.log(insertResponse);
    users = await mongoDB.find("users", {});
    console.log(users);

    console.log("======================");
    console.log("= Update document... =");
    console.log("======================");

    const updateResponse = await mongoDB.update(
      "users",
      { userName: "steve.jobs" },
      {
        $set: { userName: "steve.balmer", email: "steve.balmer@microsoft.com" },
      }
    );
    console.log(updateResponse);
    users = await mongoDB.find("users", {});
    console.log(users);

    console.log("======================");
    console.log("= Delete document... =");
    console.log("======================");

    const deleteResponse = await mongoDB.delete("users", {
      userName: "steve.balmer",
    });
    console.log(deleteResponse);
    users = await mongoDB.find("users", {});
    console.log(users);

    const disConnectResponse = await mongoDB.disConnect();
    console.log(disConnectResponse);
  }

  console.timeEnd("Benchmark");
}

main();
