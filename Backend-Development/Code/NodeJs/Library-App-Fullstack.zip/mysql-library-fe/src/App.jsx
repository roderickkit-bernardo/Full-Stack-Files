// Developer: Roderick Bernardo
// Purpose: Front-end to the library app

import Login from "./components/Login";
import { useState } from "react";
//  Use data context to share data app-wide
import { DataContext } from "./components/DataContext";

function App() {
  //  Use data context to share data app-wide
  const [refreshData, setRefreshData] = useState(new Date());

  return (
    //  Use data context to share data app-wide
    <DataContext.Provider value={[refreshData, setRefreshData]}>
      <Login></Login>
    </DataContext.Provider>
  );
}

export default App;
