/* 
  Developer: 
  Purpose: 
*/

// Declare a variable named schoolAddress and initialize it any George Brown College Campus address

// Display the value of the variable schoolAddress on the browser console

// Update variable schoolAddress and assign another George Brown College Campus address

// Display the value of the variable schoolAddress on the browser console

// Declare variable that uses the camel case style and assign any value.

// Display the value of the variable on the browser console

// Declare variable that uses the snake case style and assign any value.

// Display the value of the variable on the browser console

// Declare a variable of your choice and assign any string of your choice

// Display the value of the variable on the browser console

// Declare a variable of your choice and assign any number of your choice

// Display the value of the variable on the browser console

// Declare a variable of your choice and assign any boolean of your choice

// Display the value of the variable on the browser console

// Declare a variable of your choice and assign an array of either string or number of your choice

// Display the value of the variable on the browser console

// Declare a variable named vehicle and assign the following properties and values:
// make for example "Honda"
// model for example "Civic"
// vin for example "1GNEK13Z42R123456"

// Display the value of the variable on the browser console
