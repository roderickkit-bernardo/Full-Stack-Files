// Developer: Roderick Bernardo
// Purpose: Logs out of the app by clearing the cache and reloading the page

function logout(message) {
  if (message != "") {
    alert(message);
  }

  sessionStorage.clear();
  window.location.reload();
}

export { logout };
