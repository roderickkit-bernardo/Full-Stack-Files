/* 
  Developer: 
  Purpose: 
*/

// Coding task 1 Start

// Coding task 1 End

// Coding task 2 Start
let numbersToSort = [
  49396, 59735, 54355, 56009, 70448, 4501, 93610, 80034, 65747, 66400, 91527,
  56762, 2601, 64799, 95122, 80412, 4244, 5774, 85034, 44074,
];

// Coding task 2 End
