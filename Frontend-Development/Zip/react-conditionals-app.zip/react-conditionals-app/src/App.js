// Developer: Roderick Bernardo
// Purpose: React conditionals demo

import "bootstrap/dist/css/bootstrap.min.css";
import Menu from "./components/Menu";

function App() {
  return <Menu></Menu>;
}

export default App;
