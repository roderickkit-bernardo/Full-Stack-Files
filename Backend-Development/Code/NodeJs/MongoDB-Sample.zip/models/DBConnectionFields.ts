// Developer: Roderick Bernardo
// Purpose: MongoDB client sample

export interface DBConnectionFields {
  userName: string;
  password: string;
  url: string;
  urlScheme: string;
  db: string;
}
