// Developer: Roderick Bernardo
// Purpose: Midddleware that verifies token validity

import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

function authApiToken(req: Request, res: Response, next: NextFunction) {
  const apiKey: any = req.headers["x-api-key"];

  if (!apiKey) {
    res.status(401).json({ message: "API key is missing." });
    return;
  }

  let isTokenValid = true;
  let message = "valid token";

  try {
    console.log(`Token: ${apiKey}.`);
    jwt.verify(apiKey, String(process.env.SECRET_TOKEN_KEY));
  } catch (error: any) {
    message = error.message;
    isTokenValid = false;
  }

  console.log(`Token verification message: [${message}].`);

  if (!isTokenValid) {
    res.status(403).json({ message: "Unauthorized API key." });
    return;
  }

  next();
}

export { authApiToken };
