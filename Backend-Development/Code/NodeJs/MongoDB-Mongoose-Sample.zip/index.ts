// Developer: Roderick Bernardo
// Purpose: MongoDB mongoose sample

import * as dotenv from "dotenv";
dotenv.config();
import mongoose from "mongoose";
import { Schema } from "mongoose";

async function main() {
  console.time("Benchmark");
  const connectionString: string = `${process.env.MONGO_URL_SCHEME}${process.env.MONGO_USER}:${process.env.MONGO_PASSWORD}@${process.env.MONGO_HOST}:${process.env.MONGO_PORT}/${process.env.MONGO_DOCUMENT_NAME}?${process.env.MONGO_AUTH_SOURCE}`;
  const mongoUrl: string = `${process.env.MONGO_URL_SCHEME}${process.env.MONGO_HOST}:${process.env.MONGO_PORT}/${process.env.MONGO_DOCUMENT_NAME}`;

  try {
    await mongoose.connect(connectionString);

    console.log(`Connected to: ${mongoUrl}.`);

    const userSchema = new Schema({
      userName: String,
      email: String,
      createAt: Date,
    });

    const userModel = mongoose.model("user", userSchema);
    let users: any = null;

    console.log("===========================");
    console.log("= Select all documents... =");
    console.log("===========================");

    users = await userModel.find();
    console.log(users);

    console.log("==========================");
    console.log("= Select one document... =");
    console.log("==========================");

    users = await userModel.find({ userName: "elon.musk" });
    console.log(users);

    console.log("==========================");
    console.log("= Insert one document... =");
    console.log("==========================");

    const newUser = await userModel.create({
      userName: "steve.jobs",
      email: "steve.jobs@apple.com",
      createdAt: new Date(),
    });

    const saveResponse = await newUser.save();
    console.log(saveResponse);
    users = await userModel.find();
    console.log(users);

    console.log("======================");
    console.log("= Update document... =");
    console.log("======================");

    const updateManyResponse = await userModel.updateMany(
      { userName: `steve.jobs` },
      {
        userName: "steve.balmer",
        email: "steve.balmer@microsoft.com",
      }
    );

    console.log(updateManyResponse);
    users = await userModel.find();
    console.log(users);

    console.log("======================");
    console.log("= Delete document... =");
    console.log("======================");

    const deleteManyResponse = await userModel.deleteMany({
      userName: "steve.balmer",
    });
    console.log(deleteManyResponse);
    users = await userModel.find();
    console.log(users);
  } catch (error: any) {
    console.log(`Could not connect to: ${mongoUrl}.`);
  } finally {
    try {
      mongoose.connection.close();
      console.log(`Disconnected to: ${mongoUrl}.`);
    } catch (error: any) {
      console.log(`Could not disconnect to: ${mongoUrl}.`);
    }

    console.timeEnd("Benchmark");
  }
}

main();
