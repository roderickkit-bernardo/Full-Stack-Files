// Developer: Roderick Bernardo
// Purpose: Back-end to the library app

import * as dotenv from "dotenv";
dotenv.config();
import express from "express";
// Use cors to allow easy testing of requests that come from different domains
import cors from "cors";

// Defined routes
import { bookV1 } from "./routes/bookV1";
import { loanV1 } from "./routes/loanV1";
import { userV1 } from "./routes/userV1";

const PORT: number = process.env.PORT ? parseInt(process.env.PORT) : 3000;

const app = express();

// Middleware definitions

// Use cors to allow easy testing of requests that come from different domains
app.use(cors());
// Built-in middleware in Express that is used for parsing incoming requests with JSON payload.
app.use(express.json());

// Express toutes
app.use("/bookV1", bookV1);
app.use("/loanV1", loanV1);
app.use("/userV1", userV1);

app.all("*", (req, res) => {
  res.status(404).json({ message: "Invalid route and HTTP method." });
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
});

function shutdown() {
  console.log(`Server is shutting down.`);
  process.exit(0);
}
